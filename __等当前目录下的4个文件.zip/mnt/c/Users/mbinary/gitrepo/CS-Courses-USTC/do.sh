 rm -rf $blog/source/ustc-cs  && python3 $dt/course/gen.py  && mv $repo/index $blog/source/ustc-cs
 cp index.html $repo/source/ustc-cs/index.html
