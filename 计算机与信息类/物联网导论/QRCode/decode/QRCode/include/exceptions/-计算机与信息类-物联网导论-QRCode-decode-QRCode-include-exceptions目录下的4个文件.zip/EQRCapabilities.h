#ifndef EQRCAPABILITIES_H
#define EQRCAPABILITIES_H

#include "EQRGeneric.h"

class EQRCapabilities : public EQRGeneric
{
    public:
        EQRCapabilities(char* message);
    protected:
    private:
};

#endif // EQRCAPABILITIES_H
