#ifndef EQRDIMENSION_H
#define EQRDIMENSION_H

#include "EQRGeneric.h"

class EQRDimension : public EQRGeneric
{
    public:
        EQRDimension(char* message);
    protected:
    private:
};

#endif // EQRDIMENSION_H
