#include<stdio.h>
int main()
{
    int i=10,num=1;
    for(;i>1;i--)num = (num+1)*2;
    printf("第一天的桃子数: %d",num);
    return 0;
}
