#ifndef EQRERRORCORRECTION_H
#define EQRERRORCORRECTION_H

#include <EQRGeneric.h>


class EQRErrorCorrection : public EQRGeneric
{
    public:
        EQRErrorCorrection(char* message);
    protected:
    private:
};

#endif // EQRERRORCORRECTION_H
