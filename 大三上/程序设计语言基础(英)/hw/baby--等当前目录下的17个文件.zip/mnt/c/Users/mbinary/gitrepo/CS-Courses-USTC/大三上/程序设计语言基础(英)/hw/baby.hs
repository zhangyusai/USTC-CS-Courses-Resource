fun :: (Int | Char)->Int
fun a = 1