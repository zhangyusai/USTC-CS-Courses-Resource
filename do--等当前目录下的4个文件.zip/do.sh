 rm -rf $blog/source/ustc-cs  && python3 $repo/utils/genIndex.py  && mv $repo/index $blog/source/ustc-cs
 cp index.html $blog/source/ustc-cs/index.html
